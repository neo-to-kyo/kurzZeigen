package QueueADT;

public class QueueException extends RuntimeException {




    public QueueException(String m) {
         super(m);

    }
}