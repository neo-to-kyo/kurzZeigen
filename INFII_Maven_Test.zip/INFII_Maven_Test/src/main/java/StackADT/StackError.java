package StackADT;

public class StackError extends RuntimeException {

    public StackError(String m) {
    final long serialVersionUID = 1L;
    String message = "";
    message = m;

    }
}
